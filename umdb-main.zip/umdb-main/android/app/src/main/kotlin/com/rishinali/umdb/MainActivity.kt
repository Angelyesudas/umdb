package com.rishinali.umdb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
